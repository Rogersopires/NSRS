                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1348371
BUSINESS CARD CASES by be3D_printers is licensed under the Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

We redesigned the case to fit 85 mm x 55 mm business cards! Two options now together with 90 mm x 50 mm! More to come!

Print our card cases with hexagonal and diamond texture, designed to fit standard European 90 mm x 50 mm business cards. 

The model has two parts, the casing and inner clever spring. Load the spring with business cards, snap it into the casing and you are ready to go! In case you run out of cards, easily remove the spring with your thumb and load it again as before. 

Download, print, assemble and let's go make some business! 


Designed by the be3D Creative Team:
Tomáš Kubata - Designer
Martin Žampach - Creative Director

# Print Settings

Printer: DeeGreen
Rafts: No
Supports: No
Resolution: 0.150
Infill: 20

Notes: 
For better results, print each part separately. The case on higher resolution for finer details and the spring with no support when using the nozzle diameter 0.4 mm (3 perimeters).