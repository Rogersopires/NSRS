[MagicaVoxel : 8-bit Voxel Editor & Renderer created by ephtracy]
================================
date    : 5/27/2019

version : 0.99.4a

os      : Win32, win64, MacOS 10.7+

website : https://ephtracy.github.io/

twitter : @ ephtracy

[Credits]
================================
Icon : Font Awesome Free Version : https://fontawesome.com/
Icon : Google Material Design : https://material.io/tools/icons/?style=baseline
Icon : Ionicons : https://ionicons.com/
SDF Font : https://github.com/evanw/font-texture-generator